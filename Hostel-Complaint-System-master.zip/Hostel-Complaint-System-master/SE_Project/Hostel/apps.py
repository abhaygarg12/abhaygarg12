from django.apps import AppConfig


class HostelConfig(AppConfig):
    name = 'Hostel'
